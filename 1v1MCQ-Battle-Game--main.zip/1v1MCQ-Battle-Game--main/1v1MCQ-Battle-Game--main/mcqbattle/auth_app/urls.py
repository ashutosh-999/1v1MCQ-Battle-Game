from django.urls import path, include
from auth_app.views import index

urlpatterns = [
    # path('course/', index),
]